
<div id="mtex_LayoutGrid8">
    <div id="LayoutGrid8">
        <div class="row">
            <!-- Меню категорий -->
            <div class="col-1">
                <div id="mtex_PanelMenu1">
                    <a href="#PanelMenu1_markup" id="PanelMenu1">КАТАЛОГ</a>
                    <div id="PanelMenu1_markup">
                        <!-- Вызов виджета меню -->
                        <ul class="catalog">
                            <?= \app\components\MenuWidget::widget(['tpl' => 'menu'])?>
                        </ul>

                    </div>
                </div>
            </div>
            <!-- Конец меню категорий -->
            <div class="col-2">
                <div id="mtex_LayoutGrid14">
                    <div id="LayoutGrid14">
                        <div class="row">
                            <div class="col-1">
                                <div id="mtex_Text16">
                                    <span id="mtex_uid3"><strong>ПОПУЛЯРНАЯ ТКАНЬ</strong></span>
                                </div>
                                <hr id="Line10">
                            </div>
                        </div>
                    </div>
                </div>
                <div id="mtex_LayoutGrid11">
                    <div id="LayoutGrid11">
                        <div class="row">
                            <div class="col-1">
                                <div id="mtex_Image5">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image5" alt="">
                                </div>
                                <hr id="Line4">
                                <div id="mtex_Text8">
                                    <span id="mtex_uid4"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text11">
                                    <span id="mtex_uid5">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon6">
                                    <div id="FontAwesomeIcon6"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div id="mtex_Image6">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image6" alt="">
                                </div>
                                <hr id="Line5">
                                <div id="mtex_Text9">
                                    <span id="mtex_uid6"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text12">
                                    <span id="mtex_uid7">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon7">
                                    <div id="FontAwesomeIcon7"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div id="mtex_Image7">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image7" alt="">
                                </div>
                                <hr id="Line6">
                                <div id="mtex_Text10">
                                    <span id="mtex_uid8"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text13">
                                    <span id="mtex_uid9">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon8">
                                    <div id="FontAwesomeIcon8"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="mtex_LayoutGrid9">
                    <div id="LayoutGrid9">
                        <div class="row">
                            <div class="col-1">
                                <div id="mtex_Image2">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image2" alt="">
                                </div>
                                <hr id="Line1">
                                <div id="mtex_Text1">
                                    <span id="mtex_uid10"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text5">
                                    <span id="mtex_uid11">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon3">
                                    <div id="FontAwesomeIcon3"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div id="mtex_Image3">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image3" alt="">
                                </div>
                                <hr id="Line2">
                                <div id="mtex_Text3">
                                    <span id="mtex_uid12"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text6">
                                    <span id="mtex_uid13">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon4">
                                    <div id="FontAwesomeIcon4"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div id="mtex_Image4">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image4" alt="">
                                </div>
                                <hr id="Line3">
                                <div id="mtex_Text4">
                                    <span id="mtex_uid14"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text7">
                                    <span id="mtex_uid15">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon5">
                                    <div id="FontAwesomeIcon5"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="mtex_LayoutGrid15">
                    <div id="LayoutGrid15">
                        <div class="row">
                            <div class="col-1">
                                <div id="mtex_Text17">
                                    <span id="mtex_uid16"><strong>НОВИНКИ</strong></span>
                                </div>
                                <hr id="Line11">
                            </div>
                        </div>
                    </div>
                </div>
                <div id="mtex_LayoutGrid16">
                    <div id="LayoutGrid16">
                        <div class="row">
                            <div class="col-1">
                                <div id="mtex_Image8">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image8" alt="">
                                </div>
                                <hr id="Line7">
                                <div id="mtex_Text18">
                                    <span id="mtex_uid17"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text21">
                                    <span id="mtex_uid18">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon9">
                                    <div id="FontAwesomeIcon9"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div id="mtex_Image9">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image9" alt="">
                                </div>
                                <hr id="Line8">
                                <div id="mtex_Text19">
                                    <span id="mtex_uid19"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text22">
                                    <span id="mtex_uid20">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon10">
                                    <div id="FontAwesomeIcon10"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div id="mtex_Image10">
                                    <img src="images/19933247_144911686086542_5564267927403757568_n.jpg" id="Image10" alt="">
                                </div>
                                <hr id="Line9">
                                <div id="mtex_Text20">
                                    <span id="mtex_uid21"><strong>56 РУБ.</strong></span>
                                </div>
                                <div id="mtex_Text23">
                                    <span id="mtex_uid22">Тедди розовые</span>
                                </div>
                                <div id="mtex_FontAwesomeIcon11">
                                    <div id="FontAwesomeIcon11"><i class="fa fa-shopping-cart">&nbsp;</i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
